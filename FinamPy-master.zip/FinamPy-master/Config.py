# Чтобы получить торговый токен:
# 1. Открыть счет в "Финаме" https://open.finam.ru/registration
# 2. Зарегистрироваться в сервисе Comon https://www.comon.ru/
# 3. В личном кабинете Comon получить торговый токен https://www.comon.ru/my/trade-api/tokens

class Config:
    ClientIds = ('<Торговый счет>',)  # Торговые счета
    AccessToken = '<Токен>'  # Торговый токен
