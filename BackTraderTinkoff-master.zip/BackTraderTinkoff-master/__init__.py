from .TKStore import *
from .TKData import *  # Также подключает данные в хранилище
from .TKBroker import *  # Также подключает брокера в хранилище
