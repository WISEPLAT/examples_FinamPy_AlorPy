# Получить токен можно в настройках профиля Тинькофф Инвестиции по ссылке: https://www.tinkoff.ru/invest/settings/

class Config:
    AccountIds = (1234567890,)  # Торговые счета
    Token = '<Токен>'
